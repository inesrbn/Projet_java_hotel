package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

public class ClientController {

  private model.Hotel hotel;
  private model.Client client;
  private view.ClientsView view;
  private Vector<model.Client> clients;

  public ClientController(model.Hotel hotel, view.ClientsView view) {
    this.hotel = hotel;
    this.view = view;
    this.view.addClientListener(new addClientListener());
    this.view.SupprClientListener(new supprClientListener());
    this.view.addNoteListener(new addNoteListener());

  }

  class addClientListener implements ActionListener {

    public void actionPerformed(ActionEvent e) {
      // vérifie qu'aucun champs n'est vide
      if (!(view.getNomField().getText().isEmpty()) &&
          !(view.getPrenomField().getText().isEmpty()) &&
          !(view.getEmailField().getText().isEmpty())) {
        // récupération des information contenus dans les champs
        String nom = view.getNomField().getText();
        String prenom = view.getPrenomField().getText();
        String email = view.getEmailField().getText();

        // réinisitalisation des champs
        view.getNomField().setText("");
        view.getPrenomField().setText("");
        view.getEmailField().setText("");

        // mise a jour du model
        client = new model.Client(nom, prenom, email);
        hotel.addClient(client);

        // mise a jour de la view
        clients = hotel.getClients();
        view.updateClientList(clients);
      }
    }
  }

  class supprClientListener implements ActionListener {

    public void actionPerformed(ActionEvent e) {
      String email = view.getSupprEmailField().getText();

      if (!(email.isEmpty())) {

        clients = hotel.getClients();
        for (model.Client client : clients) {

          if (client.getEmail().equals(email)) {

            hotel.supprClient(client);
            clients = hotel.getClients();
            view.updateClientList(clients);
            view.getSupprEmailField().setText("");
            break;
          }
        }
      }
    }
  }

  class addNoteListener implements ActionListener {

    public void actionPerformed(ActionEvent e) {
      // vérifie qu'aucun champs n'est vide
      if (!(view.getNoteField().getText().isEmpty()))
        // récupération des information contenus dans les champs
        // int note = view.getNoteField().getText();

        // réinisitalisation des champs
        view.getNomField().setText("");

      // mise a jour du model
      // client = new model.Client(nom, prenom, email);
      // hotel.addClient(client);

      // mise a jour de la view
      clients = hotel.getClients();
      view.updateClientList(clients);
    }
  }
}
