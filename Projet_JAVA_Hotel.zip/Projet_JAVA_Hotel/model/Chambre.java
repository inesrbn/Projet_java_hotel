package model;

/**
 * 
 */
public class Chambre extends Commodite {

    /**
     * Default constructor
     */
    public Chambre(String type, int numero, int etage, int prix) {
        super(numero, etage, prix);
        this.type = type;
    }

    /**
     * 
     */
    public String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}