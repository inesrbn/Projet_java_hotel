package test;

import java.awt.*;
import java.awt.Dimension;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

public class ReservationView1 extends JPanel {

    private JPanel leftPanel;

    public ReservationView1() {
        leftPanel = new JPanel();
        leftPanel.setBackground(Color.RED);
        leftPanel.setLayout(new GridLayout(0, 1, 5, 5));

        // Ajout de la méthode champsAjoutReservation() dans le panneau rouge à gauche
        champsAjoutReservation();

        // Ajoute le panneau du bouton à la grille
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.33;
        c.weighty = 0.5;
        c.fill = GridBagConstraints.BOTH;
        add(leftPanel, c);

        JPanel topPanel = new JPanel();
        topPanel.setBackground(Color.PINK);

        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 0.33;
        c.weighty = 0.5;
        c.fill = GridBagConstraints.BOTH;
        add(topPanel, c);

        JPanel rightPanel = new JPanel();
        rightPanel.setBackground(Color.GREEN);

        c.gridx = 2;
        c.gridy = 0;
        c.gridheight = 2;
        c.weightx = 0.33;
        // c.weighty = 0; // Le bouton prend toute la hauteur disponible dans la grille
        c.fill = GridBagConstraints.BOTH;
        add(rightPanel, c);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(Color.BLUE);

        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 2;
        c.weightx = 0;
        c.weighty = 0.5;
        c.fill = GridBagConstraints.BOTH;
        add(bottomPanel, c);
    }

    private void champsAjoutReservation() {
        // Date de début de la réservation souhaitée
        JLabel datedebutLabel = new JLabel("Date de début: ");
        JTextField dateDebutField = new JTextField(10);
        leftPanel.add(dateDebutField);
        leftPanel.add(datedebutLabel);

        // Date de fin de la réservation souhaitée
        JLabel dateFinLabel = new JLabel("Date de Fin: ");
        JTextField dateFinField = new JTextField(10);
        leftPanel.add(dateFinField);
        leftPanel.add(dateFinLabel);

        // Initialisation du bouton Valider
        JButton buttonValider = new JButton("Valider");
        leftPanel.add(buttonValider);

        // Initialisation du champ de réponse des réservations disponibles
        JLabel reponseLabel = new JLabel("Champ de réponse :");
        JTextField reponseField = new JTextField();
        reponseLabel.setPreferredSize(new Dimension(150, 20));
        reponseField.setEditable(false);
        leftPanel.add(reponseLabel);
        leftPanel.add(reponseField);

        // Image de(s) chambre(s)
        ImageIcon imageReservation = new ImageIcon(
                getClass().getResource("/resources/chambre1.jpg"));
        JLabel imageLabel = new JLabel(imageReservation);
        add(imageLabel);

        /*
         * button.addActionListener(e-> {
         * boolean res = verifReservation(dateDebutField.getText(),
         * dateFinField.getText());
         * reponseLabel.setText(res ? "Reservation possible" :
         * "Reservation impossible");
         * reponseLabel.setVisible(true);
         * });
         */

        JPanel champsPanel = new JPanel();
        champsPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(5, 5, 5, 5);
        champsPanel.add(datedebutLabel, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        champsPanel.add(dateFinLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.fill = GridBagConstraints.NONE;
        champsPanel.add(buttonValider, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        champsPanel.add(reponseLabel, gbc);
    }

    private void optionReservation() {
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setPreferredSize(new Dimension(300, 200));
        add(scrollPane, BorderLayout.WEST);
        setVisible(true);
    }

    private void listeReservation() {
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setPreferredSize(new Dimension(200, 500));
        add(scrollPane, BorderLayout.CENTER);
        setVisible(true);

        JButton buttonAnnuler = new JButton("Annuler la Reservation");
        add(buttonAnnuler, BorderLayout.SOUTH);
    }
}
