package test;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Ines extends JPanel {

    private JLabel imageLabel;

    public Ines() {

        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(800, 600));
        // Crée un GridBagLayout pour le panneau
        setLayout(new GridBagLayout());

        JLabel imageLabel = createImageLabel();
        // Crée un panneau pour le texte
        JPanel leftPanel = createTextPanel();
        leftPanel.setBackground(Color.RED);

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.33;
        c.weighty = 1.0;
        c.fill = GridBagConstraints.BOTH;
        add(leftPanel, c);

        // Crée un panneau pour les deux zones empilées à droite
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));

        // Ajoute un panneau en haut du panneau de droite
        JPanel topPanel = new JPanel();
        topPanel.setPreferredSize(new Dimension(0, 0));

        // Crée un JLabel pour afficher une image
        ImageIcon imageIcon = new ImageIcon(getClass().getResource("/resources/imghotel.jpg"));
        imageLabel = new JLabel(imageIcon);

        // Ajoute le JLabel à topPanel
        topPanel.add(imageLabel);

        // Ajoute topPanel au panneau de droite
        rightPanel.add(topPanel);

        // Ajoute le panneau de droite à la grille
        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 0.67;
        c.weighty = 1.0;
        c.fill = GridBagConstraints.BOTH;
        add(rightPanel, c);

        // Ajoute un ComponentListener pour mettre à jour la taille de l'image lorsque
        // la taille du panneau est modifiée
        // addComponentListener(new ComponentAdapter() {
        // @Override
        // public void componentResized(ComponentEvent e) {
        // int newWidth = topPanel.getWidth();
        // int newHeight = topPanel.getHeight();
        // Image scaledImage = imageIcon.getImage().getScaledInstance(newWidth,
        // newHeight, Image.SCALE_SMOOTH);
        // imageLabel.setIcon(new ImageIcon(scaledImage));
        // }
        // });
    }

    private JLabel createImageLabel() {
        JLabel label = null;
        try {
            Image image = ImageIO.read(getClass().getResource("/resources/imghotel.jpg"));
            ImageIcon icon = new ImageIcon(image.getScaledInstance(-1, 600, Image.SCALE_SMOOTH));
            label = new JLabel(icon);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return label;
    }

    private JPanel createTextPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.setPreferredSize(new Dimension(200, 600));

        JLabel titleLabel = new JLabel("Hôtel de luxe");
        titleLabel.setFont(titleLabel.getFont().deriveFont(18.0f));
        panel.add(titleLabel);

        JLabel addressLabel = new JLabel("<html>123, avenue des Champs-Elysées<br>75008 Paris<br>France</html>");
        addressLabel.setFont(addressLabel.getFont().deriveFont(14.0f));
        panel.add(addressLabel);

        JLabel phoneLabel = new JLabel("Téléphone : +33 1 23 45 67 89");
        phoneLabel.setFont(phoneLabel.getFont().deriveFont(14.0f));
        panel.add(phoneLabel);

        return panel;
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ines");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(new Ines());
        frame.pack();
        frame.setSize(1920, 1080);
        frame.setResizable(false);
        frame.setVisible(true);
    }
}
