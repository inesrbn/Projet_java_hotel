package test.DS_POO;

public class Mystere {

    public static void mystere(int[] tab1, int[] tab2, int x) {

        x = Math.min(x, Math.min(tab1.length, tab2.length));

        for (int i = 0; i < x; i++) {

            tab1[i] = tab1[i] + tab2[i];
            tab2[i] = tab1[i] - tab2[i];
            tab1[i] = tab1[i] - tab2[i];
        }
    }

    public static void affiche(int[] tab) {

        for (int i = 0; i < tab.length - 1; i++) {

            System.out.print(tab[i] + " ");
        }

        System.out.println("\n");
    }

    public static void main(String[] args) {

        int[] monTab1 = { 2, 4, 5, 6, 7, 8, 9 };
        int[] monTab2 = { 14, 25, 34, 16, 56, 67, 19, 25 };
        mystere(monTab1, monTab2, 4);
        affiche(monTab1);
        affiche(monTab2);
    }
}