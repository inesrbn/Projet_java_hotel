package model;

import java.util.Vector;

/**
 * 
 */
public class Commodite {

    /**
     * Default constructor
     */
    public Commodite(int numero, int etage, int prix) {
        this.numero = numero;
        this.etage = etage;
        this.prix = prix;
    }

    /**
     * 
     */
    public int numero;

    /**
     * 
     */
    public int etage;

    /**
     * 
     */
    public int prix;

    /**
     * 
     */
    public Hotel hotel;

    /**
     * 
     */
    public Sejour sejour;

    /**
     * 
     */
    public Vector<Reservation> listReservation = new Vector<Reservation>();

    public void addReservation(Reservation reservation) {
        listReservation.add(reservation);
    }

    public void supprReservation(Reservation reservation) {
        listReservation.remove(reservation);
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getEtage() {
        return etage;
    }

    public void setEtage(int etage) {
        this.etage = etage;
    }

    public int getPrix() {
        return prix;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }

    public Sejour getSejour() {
        return sejour;
    }

    public void setSejour(Sejour sejour) {
        this.sejour = sejour;
    }

    public Vector<Reservation> getListReservation() {
        return listReservation;
    }
}