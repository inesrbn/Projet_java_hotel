package view;

import javax.swing.BoxLayout;

import javax.swing.JLabel;

import javax.swing.JPanel;
import java.awt.Font;
import java.awt.BorderLayout;

public class AccueilView extends JPanel {

  private JLabel nomHotel;
  private JLabel adresseHotel;
  private JLabel noteMoyenne;

  public AccueilView(model.Hotel hotel) {
    setLayout(new BorderLayout());

    JPanel infoPanel = new JPanel();
    infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));

    nomHotel = new JLabel("");
    Font font = new Font("Arial", Font.BOLD, 200);
    nomHotel.setFont(font);

    adresseHotel = new JLabel("");
    font = new Font("Arial", Font.BOLD, 40);
    adresseHotel.setFont(font);

    noteMoyenne = new JLabel("Note : ");
    font = new Font("Arial", Font.BOLD, 40);
    noteMoyenne.setFont(font);

    infoPanel.add(nomHotel);
    infoPanel.add(adresseHotel);
    infoPanel.add(noteMoyenne);

    add(infoPanel);

    new controller.AccueilController(hotel, this);
  }

  public JLabel getNomHotel() {
    return nomHotel;
  }

  public JLabel getAdresseHotel() {
    return adresseHotel;
  }

  public void updateView() {

  }

  public JLabel getNoteMoyenne() {
    return noteMoyenne;
  }
}