package model;

/**
 * 
 */
public class Produit {

    /**
     * Default constructor
     */
    public Produit(String nom, int quantite, double prix) {
        this.nom = nom;
        this.quantite = quantite;
        this.prix = prix;
    }

    /**
     * 
     */
    public String nom;

    /**
     * 
     */
    public int quantite;

    /**
     * 
     */
    public double prix;

    /**
     * 
     */
    public Hotel hotel;

    /**
     * 
     */
    public Sejour sejour;

    public void setHotel(Hotel hotel) {
        this.hotel = hotel;
    }

    public void setSejour(Sejour sejour) {
        this.sejour = sejour;
    }

    public String getNom() {
        return nom;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }

    public int getQuantite() {
        return quantite;
    }

    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }

}