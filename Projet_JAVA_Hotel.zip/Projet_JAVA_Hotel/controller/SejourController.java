package controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Vector;

public class SejourController {
    private model.Hotel hotel;
    private view.SejourView view;
    private Vector<model.Sejour> listSejour;
    private Vector<model.Produit> listProduit;

    public SejourController(model.Hotel hotel, view.SejourView view) {
        this.hotel = hotel;
        this.view = view;
        view.updateView(getAllSejour());
        // view.updateView1(getAllProduit());

    }

    private Vector<model.Sejour> getAllSejour() {
        listSejour = new Vector<model.Sejour>();
        for (model.Commodite commodite : hotel.getCommodite()) {
            if (commodite.getSejour() != null) {
                listSejour.add(commodite.getSejour());
            }
        }

        return listSejour;
    }

    // private Vector<model.Produit> getAllProduit() {
    // listProduit = new Vector<model.Produit>();
    // for (model.Commodite commodite : hotel.getCommodite()) {
    // if (commodite.getProduit() != null) {
    // listProduit.add(commodite.getProduit());
    // }
    // }

    // return listProduit;
    // }

    public void selectSejourListener(model.Sejour sejour) {

        LocalDate dateD = sejour.getDateDebut();
        LocalDate dateF = sejour.getDateFin();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String sDateD = dateD.format(formatter);
        String sDateF = dateF.format(formatter);

        view.getDebutSejourLabel().setText(sDateD);
        view.getFinSejourLabel().setText(sDateF);

        String nom = sejour.getClient().getNom();
        String prenom = sejour.getClient().getPrenom();
        String email = sejour.getClient().getEmail();

        view.getInfoClientLabel().setText(nom + "  " + prenom + "  " + email);

        view.updateView();
    }
}
