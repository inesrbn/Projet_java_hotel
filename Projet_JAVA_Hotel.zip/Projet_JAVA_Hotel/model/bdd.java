package model;

import java.time.LocalDate;

public class bdd {

    public Hotel Dozo;

    public bdd() {

        //
        Dozo = new Hotel("Doz Hotel", "102 Av. des Champs-Élysées, 75008 Paris");

        // Création de clients
        Client client1 = new Client("Thornton", "Patrick", "PatrickPThornton@dayrep.com");
        Client client2 = new Client("Miyaz", "Abdul-Qadir", "MiyazAbdul-QadirTuma@jourrapide.com");
        Client client3 = new Client("Ana Fernandes", "Julia", "AnaFernandes@gmail.es");
        Client client4 = new Client("Güçlü", "Özinal ", "Özinal-Güçlü@outlook.com");
        Client client5 = new Client("Rousset", "Jeanne", "J.rousset@hotmail.fr");
        Client client6 = new Client("Scholtz", "Radmila ", "Scholtzradmila@hotmail.de");
        Client client7 = new Client("Palmade", "Pierre", "pierrelevrai@outlook.com");
        Client client8 = new Client("Costa", "Frederic", "Fred.c91@gmail.com");
        Client client9 = new Client("Bassigno", "Jeremy", "Jerems77140@yahoo.fr");
        Client client10 = new Client("Suhaute", "Kévin", "kevinelsoat@orange.fr");
        Client client11 = new Client("a", "a", "a");

        // Ajout des clients dans la liste des clients de l'hotel
        Dozo.addClient(client1);
        Dozo.addClient(client2);
        Dozo.addClient(client3);
        Dozo.addClient(client4);
        Dozo.addClient(client5);
        Dozo.addClient(client6);
        Dozo.addClient(client7);
        Dozo.addClient(client8);
        Dozo.addClient(client9);
        Dozo.addClient(client10);
        Dozo.addClient(client11);

        // Ajout des notes pour chaque client
        client1.setNote(2);
        client2.setNote(5);
        client3.setNote(3);
        client4.setNote(4);
        client5.setNote(3);
        client6.setNote(5);
        client7.setNote(5);
        client8.setNote(2);
        client9.setNote(4);
        client10.setNote(5);

        // Chambre avec leurs caracteristiques, numéro, étage et prix
        Chambre chambre1 = new Chambre("Simple", 101, 1, 80);
        Chambre chambre2 = new Chambre("Double", 102, 1, 100);
        Suite suite1 = new Suite("Suite classique", 200, 2, 250);
        Suite suite2 = new Suite("Suite présidentielle", 300, 3, 1000);
        Dozo.addCommodite(chambre1);
        Dozo.addCommodite(chambre2);
        Dozo.addCommodite(suite1);
        Dozo.addCommodite(suite2);

        // Liste des options proposées par l'Hotel
        Option option1 = new Option("Petit déjeuner", 20);
        Option option2 = new Option("wifi", 10);
        Option option3 = new Option("Piscine", 50);
        Option option4 = new Option("Voiture de location", 50);
        Option option5 = new Option("Guide touristique", 20);
        Dozo.addOption(option1);
        Dozo.addOption(option2);
        Dozo.addOption(option3);
        Dozo.addOption(option4);
        Dozo.addOption(option5);

        // Liste des produits du Minibar
        Produit produit1 = new Produit("Chips", 1, 2.50);
        Produit produit2 = new Produit("Coca", 1, 1.50);
        Dozo.addProduit(produit1);
        Dozo.addProduit(produit2);

        // Listes de réservations et Séjours
        LocalDate date_de_debut1 = LocalDate.of(2022, 6, 1);
        LocalDate date_de_fin1 = LocalDate.of(2022, 8, 1);
        Reservation reservation1 = new Reservation(date_de_debut1, date_de_fin1);
        reservation1.setClient(client1);
        reservation1.setCommodite(chambre2);
        chambre2.addReservation(reservation1);

        LocalDate date_de_debut2 = LocalDate.of(2021, 12, 11);
        LocalDate date_de_fin2 = LocalDate.of(2021, 12, 30);
        Reservation reservation2 = new Reservation(date_de_debut2, date_de_fin2);
        reservation2.setClient(client3);
        reservation2.setCommodite(chambre1);
        chambre1.addReservation(reservation2);

        LocalDate date_de_debut3 = LocalDate.of(2023, 7, 1);
        LocalDate date_de_fin3 = LocalDate.of(2023, 7, 31);
        Reservation reservation3 = new Reservation(date_de_debut3, date_de_fin3);
        reservation3.setClient(client6);
        reservation3.setCommodite(chambre1);
        Sejour sejour1 = new Sejour(reservation3);
        chambre1.setSejour(sejour1);

        LocalDate date_de_debut4 = LocalDate.of(2023, 7, 14);
        LocalDate date_de_fin4 = LocalDate.of(2023, 7, 21);
        Reservation reservation4 = new Reservation(date_de_debut4, date_de_fin4);
        reservation4.setClient(client1);
        reservation4.setCommodite(suite1);
        Sejour sejour2 = new Sejour(reservation4);
        suite1.setSejour(sejour2);

    }

    public Hotel getHotel() {
        return Dozo;
    }
}
