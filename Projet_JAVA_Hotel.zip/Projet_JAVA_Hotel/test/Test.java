package test;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Test extends JFrame {

    public Test() {
        JFrame frame = new JFrame();
        frame.setTitle("feur");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainPanel mainPanel = new mainPanel();
        frame.add(mainPanel);
        frame.pack();
        frame.setSize(1920, 1080);
        frame.setResizable(false);
        frame.setVisible(true);
    }

    public class mainPanel extends JPanel {
        public mainPanel() {

        }
    }

    public static void main(String[] args) {
        new Test();
    }

}