package test.DS_POO;

public class Mere {
    static {
        System.out.println(" ici partie déclaration static de la mére ");
    }
    {
        System.out.println(" ici partie déclaration instance de la mére ");
    }

    public Mere() {
        System.out.println(" je suis le constructeur sans paramétre la de mére ");
    }

    public Mere(int x) {
        System.out.println(" je suis le constructeur avec paramétre la de mére ");
    }
}

class Fille extends Mere {

    static {
        System.out.println(" ici partie déclaration static de la Fille ");
    }
    {
        System.out.println(" ici partie déclaration d instance de la Fille ");
    }

    public Fille() {
        super(6);
        System.out.println(" je suis le constructeur sans paramétre de la Fille");

    }

    public Fille(int x)

    {
        System.out.println(" je suis le constructeur avec paramétre de la Fille ");
    }
}

class PetiteFille extends Fille {

    static {
        System.out.println(" ici partie déclaration static de la petite fille ");
    }
    {
        System.out.println(" ici partie déclaration instance de la petite fille ");
    }

}

class Main {

    public static void main(String[] args) {
        PetiteFille fl = new PetiteFille();
        Mere m1 = new Mere();
        Mere m2 = new Mere();
        Fille f2 = new Fille();
        Fille f3 = new PetiteFille();
    }
}
