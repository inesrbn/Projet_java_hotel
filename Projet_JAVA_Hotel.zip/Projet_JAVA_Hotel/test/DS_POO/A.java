package test.DS_POO;

public class A {

    int v;

    public A(int x) {
        v = x;
    }

    public void m1() {
    }
}

class B extends A {

    public B(int x) {
        super(x);
    }

    public void m1() {
    }

    public void m2() {
        super.m1();
    }
}

class Main {

    public static void main(String[] args) {

        A al = new A(2);

        al.m1();

        A a2 = new B(5);

        a2.m1();

        B b1 = new B(3);

        b1.m2();

    }
}
