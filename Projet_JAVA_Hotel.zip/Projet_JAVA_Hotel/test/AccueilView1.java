package test;

import javax.swing.*;
import java.awt.*;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class AccueilView1 extends JFrame {
    public AccueilView1() {
        // Crée un conteneur racine avec un GridBagLayout
        Container contentPane = getContentPane();
        contentPane.setLayout(new GridBagLayout());

        // Crée un panneau pour le bouton
        JPanel leftPanel = new JPanel();
        leftPanel.setBackground(Color.RED);

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.33;
        c.weighty = 1.0; //
        c.fill = GridBagConstraints.BOTH;
        contentPane.add(leftPanel, c);

        // Crée un panneau pour les deux zones empilées à droite
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));

        // Ajoute un panneau en haut du panneau de droite
        JPanel topPanel = new JPanel();
        topPanel.setBackground(Color.GREEN);
        topPanel.setPreferredSize(new Dimension(0, 100)); // Fixe une hauteur de 100 pixels pour ce panneau
        rightPanel.add(topPanel);

        // Ajoute le panneau de droite à la grille
        c.gridx = 1; // La position x du panneau de droite dans la grille
        c.gridy = 0; // La position y du panneau de droite dans la grille
        c.weightx = 0.67; // Le panneau de droite prend 2/3 de la largeur disponible dans la grille
        c.weighty = 1.0; // Le panneau de droite prend toute la hauteur disponible dans la grille
        c.fill = GridBagConstraints.BOTH; // Le panneau de droite se remplit horizontalement et verticalement
        contentPane.add(rightPanel, c);

        // Configure la fenêtre
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 500);
        setVisible(true);
    }

    public static void main(String[] args) {
        new AccueilView1();
    }
}