package model;

import java.util.Vector;

/**
 *
 */
public class Client {

    /**
     * Default constructor
     */
    public Client(String nom, String prenom, String email) {
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;

    }

    /**
     *
     */
    public String nom;

    /**
     *
     */
    public String prenom;

    /**
     *
     */
    public String email;

    /**
     *
     */
    public int note = 0;

    /**
     *
     */
    public Hotel hotel;

    /**
     *
     */
    public Vector<Reservation> listReservation = new Vector<Reservation>();

    public void addReservation(Reservation reservation) {
        listReservation.add(reservation);
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getNote() {
        return note;
    }

    public void setNote(int note) {
        this.note = note;
    }
}
