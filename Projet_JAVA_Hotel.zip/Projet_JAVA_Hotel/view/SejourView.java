package view;

import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.util.Vector;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JScrollPane;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.awt.event.ActionEvent;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;

public class SejourView extends JPanel {

    private controller.SejourController rc;
    public model.Hotel hotel;
    private Vector<model.Sejour> listSejour;
    private Vector<model.Produit> listProduit;

    private JPanel addchampProduit;
    private JPanel addMilieuPage;
    private JPanel leftPanel;
    private JPanel middlePanel;
    private JPanel rightPanel;
    private JLabel dateDebutSejourLabel;
    private JLabel dateFinSejourLabel;
    private JButton selectionnerButton;

    private JScrollPane listSejourScrollPane;
    private JScrollPane scrollPaneProduit;
    private JLabel infoClientLabel;
    private Font changeFont;

    public SejourView(model.Hotel hotel) {
        this.hotel = hotel;

        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        leftPanel = new JPanel();
        leftPanel.setBackground(Color.RED);

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 1;
        c.weighty = 1;
        c.fill = GridBagConstraints.BOTH;
        add(leftPanel, c);

        middlePanel = new JPanel();
        middlePanel.setBackground(Color.YELLOW);

        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 1;
        c.weighty = 1;
        c.fill = GridBagConstraints.BOTH;
        add(middlePanel, c);

        rightPanel = new JPanel();
        rightPanel.setBackground(Color.GREEN);

        c.gridx = 2;
        c.gridy = 0;
        c.weightx = 1;
        c.weighty = 1;
        c.fill = GridBagConstraints.BOTH;
        add(rightPanel, c);

        champProduit();
        milieuPage();
        tabListSejour();
        rc = new controller.SejourController(hotel, this);

    }

    private void tabListSejour() {
        // création du tableau des séjours
        int nbLine;
        if (listSejour == null) {
            nbLine = 0;
        } else {
            nbLine = listSejour.size();
        }
        JPanel tabSejour = new JPanel(new GridLayout(0, 5));

        // entete du tableau
        changeFont = new Font("Arial Black", Font.BOLD, 15);

        JLabel colClient = new JLabel("Client");
        colClient.setBackground(Color.gray);
        colClient.setOpaque(true);
        colClient.setPreferredSize(new Dimension(150, 26));
        colClient.setHorizontalAlignment(JLabel.CENTER);
        colClient.setFont(changeFont);

        JLabel colChambre = new JLabel("Chambre");
        colChambre.setBackground(Color.gray);
        colChambre.setOpaque(true);
        colChambre.setHorizontalAlignment(JLabel.CENTER);
        colChambre.setFont(changeFont);

        JLabel colDateDeb = new JLabel("Date de début");
        colDateDeb.setBackground(Color.gray);
        colDateDeb.setOpaque(true);
        colDateDeb.setHorizontalAlignment(JLabel.CENTER);
        colDateDeb.setFont(changeFont);

        JLabel colDateFin = new JLabel("Date de fin");
        colDateFin.setBackground(Color.gray);
        colDateFin.setOpaque(true);
        colDateFin.setHorizontalAlignment(JLabel.CENTER);
        colDateFin.setFont(changeFont);

        JLabel selectionner = new JLabel("Sélectionner");
        selectionner.setBackground(Color.gray);
        selectionner.setOpaque(true);
        selectionner.setHorizontalAlignment(JLabel.CENTER);
        selectionner.setFont(changeFont);

        tabSejour.add(colClient);
        tabSejour.add(colChambre);
        tabSejour.add(colDateDeb);
        tabSejour.add(colDateFin);
        tabSejour.add(selectionner);

        // corps du tableau
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        for (int i = 0; i < nbLine; i++) {

            JLabel nomClient = new JLabel(listSejour.get(i).getClient().getNom());
            nomClient.setHorizontalAlignment(JLabel.CENTER);

            JLabel numeroChambre = new JLabel(String.valueOf(listSejour.get(i).getCommodite().getNumero()));
            numeroChambre.setHorizontalAlignment(JLabel.CENTER);

            JLabel dateDebut = new JLabel(listSejour.get(i).getDateDebut().format(format).toString());
            dateDebut.setHorizontalAlignment(JLabel.CENTER);

            JLabel dateFin = new JLabel(listSejour.get(i).getDateFin().format(format).toString());
            dateFin.setHorizontalAlignment(JLabel.CENTER);

            selectionnerButton = new JButton("Sélectionner");
            selectionnerButton.setHorizontalAlignment(JLabel.CENTER);
            addSelectionnerButtonActionListener(selectionnerButton, i, listSejour);

            if (i % 2 == 1) {
                nomClient.setBackground(Color.lightGray);
                nomClient.setOpaque(true);
                numeroChambre.setBackground(Color.lightGray);
                numeroChambre.setOpaque(true);
                dateDebut.setBackground(Color.lightGray);
                dateDebut.setOpaque(true);
                dateFin.setBackground(Color.lightGray);
                dateFin.setOpaque(true);
                selectionnerButton.setBackground(Color.lightGray);
                selectionnerButton.setOpaque(true);
            } else {
                selectionnerButton.setBackground(Color.white);
                selectionnerButton.setOpaque(true);
            }

            selectionner.setFont(changeFont);

            tabSejour.add(nomClient);
            tabSejour.add(numeroChambre);
            tabSejour.add(dateDebut);
            tabSejour.add(dateFin);
            tabSejour.add(selectionnerButton);
        }

        listSejourScrollPane = new JScrollPane(tabSejour);
        // listSejourScrollPane.setPreferredSize(new Dimension(500, 900));
        leftPanel.add(listSejourScrollPane, BorderLayout.CENTER);
    }

    private void champProduit() {
        // création du tableau des options
        int nbLine;
        if (listProduit == null) {
            nbLine = 0;
        } else {
            nbLine = listProduit.size();
        }
        JPanel tabProduit = new JPanel(new GridLayout(0, 4));

        // entete du tableau
        changeFont = new Font("Arial Black", Font.BOLD, 15);

        JLabel colNom = new JLabel("Produit");
        colNom.setBackground(Color.gray);
        colNom.setOpaque(true);
        colNom.setPreferredSize(new Dimension(150, 26));
        colNom.setHorizontalAlignment(JLabel.CENTER);
        colNom.setFont(changeFont);

        JLabel colQuantite = new JLabel("Quantité");
        colQuantite.setBackground(Color.gray);
        colQuantite.setOpaque(true);
        colQuantite.setHorizontalAlignment(JLabel.CENTER);
        colQuantite.setFont(changeFont);

        JLabel colPrix = new JLabel("Prix");
        colPrix.setBackground(Color.gray);
        colPrix.setOpaque(true);
        colPrix.setHorizontalAlignment(JLabel.CENTER);
        colPrix.setFont(changeFont);

        JLabel selection = new JLabel("Selection");
        selection.setBackground(Color.gray);
        selection.setOpaque(true);
        selection.setHorizontalAlignment(JLabel.CENTER);
        selection.setFont(changeFont);

        tabProduit.add(colNom);
        tabProduit.add(colQuantite);
        tabProduit.add(colPrix);
        tabProduit.add(selection);

        // corps du tableau
        for (int i = 0; i < nbLine; i++) {

            JLabel nomProduit = new JLabel(listProduit.get(i).getNom());
            nomProduit.setHorizontalAlignment(JLabel.CENTER);

            JLabel quantiteProduit = new JLabel(String.valueOf(listProduit.get(i).getQuantite()));
            quantiteProduit.setHorizontalAlignment(JLabel.CENTER);

            JLabel prixProduit = new JLabel(String.valueOf(listProduit.get(i).getPrix()));
            prixProduit.setHorizontalAlignment(JLabel.CENTER);

            JCheckBox selecteur = new JCheckBox("");
            selecteur.setHorizontalAlignment(JLabel.CENTER);
            // addAnnulerButtonActionListener(selecteur, i, listOption);

            if (i % 2 == 1) {
                nomProduit.setBackground(Color.lightGray);
                nomProduit.setOpaque(true);
                quantiteProduit.setBackground(Color.lightGray);
                quantiteProduit.setBackground(Color.lightGray);
                prixProduit.setOpaque(true);
                prixProduit.setOpaque(true);
                selecteur.setBackground(Color.lightGray);
                selecteur.setOpaque(true);
            }

            tabProduit.add(nomProduit);
            tabProduit.add(quantiteProduit);
            tabProduit.add(prixProduit);
            tabProduit.add(selecteur);
        }

        scrollPaneProduit = new JScrollPane(tabProduit);
        scrollPaneProduit.setMaximumSize(scrollPaneProduit.getPreferredSize());
        // scrollPaneProduit.setPreferredSize(new Dimension(500, 700));
        rightPanel.add(scrollPaneProduit);
    }

    private void milieuPage() {

        addMilieuPage = new JPanel();
        addMilieuPage.setLayout(new BoxLayout(addMilieuPage, BoxLayout.Y_AXIS));

        JPanel addhautpagePanel = new JPanel();
        // Date de début de la réservation souhaitée
        JLabel debutSejourLabel = new JLabel("Date de début: ");
        dateDebutSejourLabel = new JLabel("");
        addhautpagePanel.add(debutSejourLabel);
        addhautpagePanel.add(dateDebutSejourLabel);

        addMilieuPage.add(addhautpagePanel);

        JPanel addhautpagePanel1 = new JPanel();
        // Date de fin de la réservation souhaitée
        JLabel finSejourLabel = new JLabel("Date de Fin: ");
        dateFinSejourLabel = new JLabel("");
        addhautpagePanel1.add(finSejourLabel);
        addhautpagePanel1.add(dateFinSejourLabel);

        addMilieuPage.add(addhautpagePanel1);

        JPanel addhautpagePanel3 = new JPanel();
        // les informations sur le client
        JLabel TitleInfoClientLabel = new JLabel("Informations sur le client :");
        infoClientLabel = new JLabel("");
        // nomClientField.setEditable(false);
        addhautpagePanel3.add(TitleInfoClientLabel);
        addhautpagePanel3.add(infoClientLabel);

        JPanel addhautpagePanel6 = new JPanel();
        addhautpagePanel6.add(new JLabel("Produits commandés : "));
        addMilieuPage.add(addhautpagePanel6);

        JPanel addhautpagePanel4 = new JPanel();
        // Scroll pane contenant la liste des produits commandés
        JScrollPane produitScrollPane = new JScrollPane();
        produitScrollPane.setPreferredSize(new Dimension(300, 200));
        addhautpagePanel4.add(produitScrollPane);
        addMilieuPage.add(addhautpagePanel4);

        JPanel addhautpagePanel5 = new JPanel();
        // Affichage du coût total des produits commandés
        JLabel coutLabel = new JLabel("");
        addhautpagePanel5.setPreferredSize(new Dimension(300, 100));

        // JTextField coutField = new JTextField();
        // nomClientField.setEditable(false);
        addhautpagePanel5.add(coutLabel);
        // addhautpagePanel5.add(coutField);

        addMilieuPage.add(addhautpagePanel5);

        middlePanel.add(addMilieuPage);
    }

    private void addSelectionnerButtonActionListener(JButton selectionnerButton, int index,
            Vector<model.Sejour> listSejour) {

        selectionnerButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                model.Sejour sejour = listSejour.get(index);
                rc.selectSejourListener(sejour);
            }
        });
    }

    public JLabel getDebutSejourLabel() {
        return dateDebutSejourLabel;
    }

    public JLabel getFinSejourLabel() {
        return dateFinSejourLabel;
    }

    public JLabel getInfoClientLabel() {
        return infoClientLabel;
    }

    public void updateView() {

    }

    public void updateView(Vector<model.Sejour> listSejour) {
        this.listSejour = listSejour;
        leftPanel.remove(listSejourScrollPane);
        tabListSejour();
        leftPanel.revalidate();
        leftPanel.repaint();
    }

    public void updateView1(Vector<model.Produit> listProduit) {
        this.listProduit = listProduit;
        rightPanel.remove(scrollPaneProduit);
        champProduit();
        rightPanel.revalidate();
        rightPanel.repaint();
    }

}
